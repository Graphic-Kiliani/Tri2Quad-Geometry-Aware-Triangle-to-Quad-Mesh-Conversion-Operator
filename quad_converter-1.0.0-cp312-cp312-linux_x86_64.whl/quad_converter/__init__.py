"""
Quad Converter - High-performance triangle-to-quad mesh converter

This package provides tools to convert triangle meshes into quad-dominant meshes
while preserving normal consistency and mesh quality.
"""

__version__ = "1.0.0"
__author__ = "Kiliani Zhang"

# Try to import the compiled C++ extension
try:
    # Import the compiled module (quad_converter.so)
    from .quad_converter import tri_to_quad
    
    # Also provide an alias for compatibility
    convert_tri_to_quad = tri_to_quad
    
    __all__ = ['tri_to_quad', 'convert_tri_to_quad', '__version__']
    
except ImportError as e:
    import warnings
    warnings.warn(
        f"Failed to import quad_converter C++ extension: {e}\n"
        "The package may not have been properly compiled. "
        "Please reinstall with: pip install --force-reinstall quad-converter"
    )
    
    # Provide dummy functions for graceful degradation
    def tri_to_quad(*args, **kwargs):
        raise RuntimeError(
            "quad_converter C++ extension is not available. "
            "Please reinstall the package."
        )
    
    convert_tri_to_quad = tri_to_quad
    
    __all__ = ['tri_to_quad', 'convert_tri_to_quad', '__version__']


# Convenience function for easy imports
def get_version():
    """Return the package version string"""
    return __version__

